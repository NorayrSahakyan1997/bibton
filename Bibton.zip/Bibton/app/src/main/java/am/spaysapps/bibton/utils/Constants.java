package am.spaysapps.bibton.utils;

public final class Constants {
    private Constants(){}

    public static int CURRENT_PAGE=0;
    public static int COINS_TRANSFERRING_DURABILITY=3000;


}
